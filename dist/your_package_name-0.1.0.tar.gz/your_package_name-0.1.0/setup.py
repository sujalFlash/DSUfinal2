from setuptools import setup, find_packages

setup(
    name="your_package_name",  # Replace with your package name
    version="0.1.0",  # Replace with your version number
    description="A short description of your package",
    packages=find_packages(),  # Automatically find packages
)