from django.apps import AppConfig


class ImageaugmentationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ImageAugmentation'
