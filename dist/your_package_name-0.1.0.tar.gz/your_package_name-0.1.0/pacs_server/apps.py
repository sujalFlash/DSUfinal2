from django.apps import AppConfig


class PacsServerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pacs_server'
